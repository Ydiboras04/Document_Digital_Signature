# SecureDoc Chain — database export (2026-08-21)

Snapshot of the development database plus the document files it references.

## What's in here

- `securedoc_chain.sql` — full schema + data dump (`pg_dump --clean --if-exists --no-owner --no-privileges`)
- `uploads/` — the two files the `documents` rows point at

**Both parts are required.** Document bytes are NOT stored in the database.
`documents.file_path` holds a storage key, and `DiskFileStorage` reads the file
from `./uploads/<key>`. Restoring only the SQL leaves two documents whose
content cannot be loaded.

## Restore

1. Create the role and database (the dump does not create either):

   ```sql
   CREATE ROLE securedoc_chain_app LOGIN PASSWORD '<your password>';
   CREATE DATABASE securedoc_chain OWNER securedoc_chain_app;
   ```

2. Load the dump:

   ```bash
   psql -h localhost -U securedoc_chain_app -d securedoc_chain -f securedoc_chain.sql
   ```

3. Copy `uploads/` into the backend repo root (alongside `package.json`), so the
   files land at `./uploads/<key>`. Merge into the existing directory if present.

4. Point `.env` at the new database and set a `JWT_SECRET` (the server refuses to
   start without one). `.env` is gitignored and deliberately not included here.

## After restoring: the identity problem

Private keys live only in each device's secure storage and were never on the
server, so restoring this dump does NOT give you the ability to sign as these
users on another machine.

- `mikle` (admin) can only sign from the Windows machine that registered.
- On the home PC the app has no stored identity, so it will show Register.
- Registering there creates a NEW user. It cannot reuse `mikle`'s email —
  `POST /users` rejects duplicates with `DuplicateEmailError`.
- That new user will not be an admin. Promote it:
  `npm run db:promote-admin -- <new email>`, then restart the app so the fresh
  JWT carries `isAdmin` (the flag is read from the token, not the database).

Existing signatures still verify anywhere, because verification needs only the
public keys, which are in the dump.

## Data contents

5 users, 2 documents, 3 signatures.

- `mikle` — admin, registered from the Windows app (real email address)
- `signer2-782627` — test account created to exercise a 2-signer chain
- `alice` (admin), `bob`, `carol` — dev seed fixtures

`Selection_Projet.pdf` carries a verified 2-link chain (mikle → signer2).
The PNG carries a single signature by mikle.
